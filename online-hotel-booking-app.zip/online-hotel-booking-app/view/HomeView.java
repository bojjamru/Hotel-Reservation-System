package view;

public class HomeView {

    //method to print main menu
    public static void DisplayHomeView() {
        System.out.println("==============================");
        System.out.println("Welcome to the Grand Hotel App");
        System.out.println("==============================");
        System.out.println("Please select an option:");
        System.out.println("1. Admin Login");
        System.out.println("2. Guest Login");
        System.out.println("3. Admin Registration");
        System.out.println("4. Guest Registration");
    }
}

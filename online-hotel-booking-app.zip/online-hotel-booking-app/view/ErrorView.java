package view;

public class ErrorView {
    
    //method to print invalid credentials
    public void print(){
        System.out.println("Login falied, please try again");
    }
    
}

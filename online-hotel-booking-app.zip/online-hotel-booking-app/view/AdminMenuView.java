package view;

public class AdminMenuView {
    
    //method to print admin menu
    public static void DisplayAdminMenuView() {
        System.out.println("Please select an option:");
        System.out.println("1. Browse Rooms");
        System.out.println("2. Add New Rooms");
        System.out.println("3. Update Room");
        System.out.println("4. Delete Room");
        System.out.println("5. View Guests");
        System.out.println("6. Register New Guest");
        System.out.println("7. Delete Guest");
        System.out.println("8. View Admins");
        System.out.println("9. Register New Admin");
        System.out.println("10. Delete Admin");
        System.out.println("11. Exit");
    }
}

package view;

public class GuestMenuView {

    //method to print guest menu
    public static void DisplayGuestMenu() {
        System.out.println("Please select an option:");
        System.out.println("1. Browse Rooms");
        System.out.println("2. Reserve a Room");
        System.out.println("3. Modify Reservation");
        System.out.println("4. Cancel Reservation");
        System.out.println("5. Exit");
    }
    
}

package model;

public interface Command {

    //method to execute command
    void execute();

}